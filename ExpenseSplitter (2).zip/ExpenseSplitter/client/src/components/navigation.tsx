import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Link, useLocation } from "wouter";
import { 
  GraduationCap, 
  Search, 
  ShoppingCart, 
  User, 
  Menu, 
  Home, 
  Calendar, 
  Settings,
  LogOut 
} from "lucide-react";

export default function Navigation() {
  const { user } = useAuth();
  const [location] = useLocation();
  const [cartCount] = useState(2); // Mock cart count

  const initials = user?.firstName && user?.lastName 
    ? `${user.firstName[0]}${user.lastName[0]}` 
    : user?.email?.[0]?.toUpperCase() || "U";

  return (
    <>
      {/* Desktop Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-university-blue rounded-lg flex items-center justify-center">
                <GraduationCap className="text-white" size={20} />
              </div>
              <div>
                <h1 className="font-bold text-lg text-gray-900">Campus Rental</h1>
                <p className="text-xs text-gray-500">University Marketplace</p>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link 
                href="/" 
                className={`transition-colors ${
                  location === "/" ? "text-university-blue" : "text-gray-700 hover:text-university-blue"
                }`}
              >
                Browse
              </Link>
              <Link 
                href="/my-rentals" 
                className="text-gray-700 hover:text-university-blue transition-colors"
              >
                My Rentals
              </Link>
              {user?.isAdmin && (
                <Link 
                  href="/admin" 
                  className={`transition-colors ${
                    location === "/admin" ? "text-university-blue" : "text-gray-700 hover:text-university-blue"
                  }`}
                >
                  Admin
                </Link>
              )}
            </nav>

            {/* User Actions */}
            <div className="flex items-center space-x-4">
              {/* Search Icon (Mobile) */}
              <Button variant="ghost" size="sm" className="md:hidden">
                <Search size={20} />
              </Button>
              
              {/* Cart */}
              <div className="relative">
                <Button variant="ghost" size="sm">
                  <ShoppingCart size={20} />
                  {cartCount > 0 && (
                    <Badge className="absolute -top-1 -right-1 bg-amber-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center p-0">
                      {cartCount}
                    </Badge>
                  )}
                </Button>
              </div>

              {/* User Profile */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-university-light rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">{initials}</span>
                    </div>
                    <span className="hidden md:inline text-sm font-medium">
                      {user?.firstName || "User"}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="flex items-center space-x-2">
                      <User size={16} />
                      <span>Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/my-rentals" className="flex items-center space-x-2">
                      <Calendar size={16} />
                      <span>My Rentals</span>
                    </Link>
                  </DropdownMenuItem>
                  {user?.isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin" className="flex items-center space-x-2">
                        <Settings size={16} />
                        <span>Admin Panel</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem 
                    onClick={() => window.location.href = '/api/logout'}
                    className="flex items-center space-x-2 text-red-600"
                  >
                    <LogOut size={16} />
                    <span>Sign Out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Mobile Menu Toggle */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="sm" className="md:hidden">
                    <Menu size={20} />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-80">
                  <div className="flex flex-col space-y-4 mt-8">
                    <Link href="/" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100">
                      <Home size={20} />
                      <span>Browse</span>
                    </Link>
                    <Link href="/my-rentals" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100">
                      <Calendar size={20} />
                      <span>My Rentals</span>
                    </Link>
                    {user?.isAdmin && (
                      <Link href="/admin" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100">
                        <Settings size={20} />
                        <span>Admin Panel</span>
                      </Link>
                    )}
                    <Button 
                      variant="ghost" 
                      className="justify-start text-red-600"
                      onClick={() => window.location.href = '/api/logout'}
                    >
                      <LogOut size={20} className="mr-3" />
                      Sign Out
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Search Bar (Desktop) */}
          <div className="hidden md:block pb-4">
            <div className="relative max-w-2xl mx-auto">
              <Input
                type="text"
                placeholder="Search books, calculators, sports gear..."
                className="pl-12 pr-4 py-3"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40">
        <div className="grid grid-cols-5 h-16">
          <Link href="/" className={`flex flex-col items-center justify-center ${location === "/" ? "text-university-blue" : "text-gray-400"}`}>
            <Home size={20} />
            <span className="text-xs mt-1">Home</span>
          </Link>
          <Button variant="ghost" className="flex flex-col items-center justify-center text-gray-400">
            <Search size={20} />
            <span className="text-xs mt-1">Search</span>
          </Button>
          <Link href="/my-rentals" className="flex flex-col items-center justify-center text-gray-400">
            <Calendar size={20} />
            <span className="text-xs mt-1">Rentals</span>
          </Link>
          <Button variant="ghost" className="flex flex-col items-center justify-center text-gray-400 relative">
            <ShoppingCart size={20} />
            <span className="text-xs mt-1">Cart</span>
            {cartCount > 0 && (
              <Badge className="absolute -top-1 -right-1 bg-amber-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center p-0">
                {cartCount}
              </Badge>
            )}
          </Button>
          <Link href="/profile" className="flex flex-col items-center justify-center text-gray-400">
            <User size={20} />
            <span className="text-xs mt-1">Profile</span>
          </Link>
        </div>
      </div>
    </>
  );
}
