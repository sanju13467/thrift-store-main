import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Heart, Star } from "lucide-react";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  onRentNow: () => void;
}

export default function ProductCard({ product, onRentNow }: ProductCardProps) {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();
  const [isWishlisted, setIsWishlisted] = useState(false);

  const wishlistMutation = useMutation({
    mutationFn: async () => {
      if (isWishlisted) {
        await apiRequest("DELETE", `/api/wishlist/${product.id}`);
      } else {
        await apiRequest("POST", "/api/wishlist", { productId: product.id });
      }
    },
    onSuccess: () => {
      setIsWishlisted(!isWishlisted);
      toast({
        title: isWishlisted ? "Removed from wishlist" : "Added to wishlist",
        description: isWishlisted 
          ? "Item removed from your wishlist" 
          : "Item added to your wishlist",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wishlist"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update wishlist. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAuthenticated) {
      toast({
        title: "Sign in required",
        description: "Please sign in to add items to your wishlist",
        variant: "destructive",
      });
      return;
    }
    wishlistMutation.mutate();
  };

  const handleRentNow = () => {
    if (!isAuthenticated) {
      toast({
        title: "Sign in required",
        description: "Please sign in to rent items",
        variant: "destructive",
      });
      return;
    }
    onRentNow();
  };

  const getAvailabilityBadge = () => {
    if (product.isAvailable) {
      return <Badge className="bg-success-green/10 text-success-green">Available</Badge>;
    } else {
      return <Badge className="bg-red-500 text-white font-semibold">Out of Stock</Badge>;
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative">
        <img
          src={product.imageUrl || "https://images.unsplash.com/photo-1509228468518-180dd4864904?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"}
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-3 left-3">
          {getAvailabilityBadge()}
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full hover:bg-gray-50"
          onClick={handleWishlistToggle}
          disabled={wishlistMutation.isPending}
        >
          <Heart
            size={16}
            className={isWishlisted ? "fill-red-500 text-red-500" : "text-gray-400"}
          />
        </Button>
      </div>

      <CardContent className={`p-4 ${!product.isAvailable ? 'bg-red-50 border-l-4 border-red-500' : ''}`}>
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-gray-900 text-lg leading-tight line-clamp-2">
            {product.name}
          </h3>
          {product.subcategory && (
            <span className="text-sm text-gray-500 ml-2 flex-shrink-0">
              {product.subcategory}
            </span>
          )}
        </div>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center justify-between mb-4">
          <div>
            <span className={`text-xl font-bold ${product.isAvailable ? 'text-university-blue' : 'text-gray-400'}`}>
              ₹{product.dailyRate}
            </span>
            <span className={`text-sm ${product.isAvailable ? 'text-gray-500' : 'text-gray-400'}`}>
              /day
            </span>
          </div>
          <div className="text-right">
            <div className={`text-sm ${product.isAvailable ? 'text-gray-500' : 'text-gray-400'}`}>
              Weekly: <span className="font-medium">₹{product.weeklyRate}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-4">
          <div className="flex items-center">
            <Star className="text-amber-400 fill-amber-400" size={16} />
            <span className="ml-1 text-sm font-medium">{product.rating || "0.0"}</span>
            <span className="text-gray-500 text-sm ml-1">
              ({product.reviewCount || 0} reviews)
            </span>
          </div>
        </div>

        <Button
          className={`w-full font-medium ${
            product.isAvailable
              ? "bg-university-blue hover:bg-university-blue/90 text-white"
              : "bg-red-500 hover:bg-red-600 text-white"
          }`}
          onClick={handleRentNow}
          disabled={!product.isAvailable}
        >
          {product.isAvailable ? "Rent Now" : "Notify When Available"}
        </Button>
      </CardContent>
    </Card>
  );
}
