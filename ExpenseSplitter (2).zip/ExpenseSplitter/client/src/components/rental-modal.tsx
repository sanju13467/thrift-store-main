import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Smartphone, CreditCard } from "lucide-react";
import type { Product } from "@shared/schema";

interface RentalModalProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
}

export default function RentalModal({ product, isOpen, onClose }: RentalModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("phonepay");

  const calculateRental = () => {
    if (!startDate || !endDate) return { days: 0, subtotal: 0, deposit: 0, total: 0 };
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
    
    const dailyRate = parseFloat(product.dailyRate);
    const deposit = parseFloat(product.securityDeposit);
    const subtotal = dailyRate * days;
    const total = subtotal + deposit;
    
    return { days, subtotal, deposit, total };
  };

  const { days, subtotal, deposit, total } = calculateRental();

  const rentalMutation = useMutation({
    mutationFn: async () => {
      if (!startDate || !endDate) {
        throw new Error("Please select rental dates");
      }
      
      const rentalData = {
        productId: product.id,
        startDate: new Date(startDate).toISOString(),
        endDate: new Date(endDate).toISOString(),
        totalAmount: subtotal.toString(),
        securityDeposit: deposit.toString(),
        paymentMethod,
      };
      
      await apiRequest("POST", "/api/rentals", rentalData);
    },
    onSuccess: () => {
      toast({
        title: "Rental confirmed!",
        description: "Check your email for rental details and pickup instructions.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rentals/my"] });
      onClose();
      resetForm();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to create rental. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setStartDate("");
    setEndDate("");
    setPaymentMethod("phonepay");
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Set minimum date to today
  const today = new Date().toISOString().split('T')[0];
  const minEndDate = startDate || today;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md mx-auto max-h-screen overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Rent Item</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Product Summary */}
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gray-200 rounded-lg flex-shrink-0 overflow-hidden">
              <img
                src={product.imageUrl || "https://images.unsplash.com/photo-1509228468518-180dd4864904?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h4 className="font-medium text-gray-900">{product.name}</h4>
              <p className="text-sm text-gray-600">₹{product.dailyRate}/day</p>
            </div>
          </div>

          {/* Rental Dates */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">Rental Period</Label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-gray-500 mb-1">Start Date</Label>
                <Input
                  type="date"
                  value={startDate}
                  min={today}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div>
                <Label className="text-xs text-gray-500 mb-1">End Date</Label>
                <Input
                  type="date"
                  value={endDate}
                  min={minEndDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Pricing Breakdown */}
          {days > 0 && (
            <Card>
              <CardContent className="p-4">
                <h5 className="font-medium text-gray-900 mb-3">Rental Summary</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Daily rate × {days} days</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Security deposit</span>
                    <span>₹{deposit.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-gray-200 pt-2 flex justify-between font-medium">
                    <span>Total</span>
                    <span>₹{total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Payment Method */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-3">Payment Method</Label>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
              <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value="phonepay" id="phonepay" />
                <Label htmlFor="phonepay" className="flex items-center space-x-2 cursor-pointer flex-1">
                  <Smartphone className="text-university-blue" size={20} />
                  <span className="text-sm font-medium">PhonePe</span>
                </Label>
              </div>
              <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value="cod" id="cod" />
                <Label htmlFor="cod" className="flex items-center space-x-2 cursor-pointer flex-1">
                  <CreditCard className="text-success-green" size={20} />
                  <span className="text-sm font-medium">Cash on Delivery</span>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={handleClose}
              disabled={rentalMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              className="flex-1 bg-university-blue hover:bg-university-blue/90"
              onClick={() => rentalMutation.mutate()}
              disabled={!startDate || !endDate || days <= 0 || rentalMutation.isPending}
            >
              {rentalMutation.isPending ? "Processing..." : "Confirm Rental"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
