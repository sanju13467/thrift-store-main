import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import Navigation from "@/components/navigation";
import { Box, CheckCircle, Clock, IndianRupee, Users, Calendar, Settings } from "lucide-react";
import type { Product, Rental } from "@shared/schema";

export default function Admin() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();

  // Redirect to home if not authenticated or not admin
  useEffect(() => {
    if (!authLoading && (!isAuthenticated || !user?.isAdmin)) {
      toast({
        title: "Unauthorized",
        description: "Admin access required. Redirecting...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 1000);
      return;
    }
  }, [isAuthenticated, authLoading, user, toast]);

  const { data: products = [], isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products"],
    enabled: isAuthenticated && user?.isAdmin,
  });

  const { data: rentals = [], isLoading: rentalsLoading } = useQuery({
    queryKey: ["/api/admin/rentals"],
    enabled: isAuthenticated && user?.isAdmin,
  });

  if (authLoading || (!isAuthenticated || !user?.isAdmin)) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-university-blue mx-auto mb-4"></div>
          <p className="text-gray-600">Checking permissions...</p>
        </div>
      </div>
    );
  }

  const availableProducts = products.filter((p: Product) => p.isAvailable);
  const unavailableProducts = products.filter((p: Product) => !p.isAvailable);
  const activeRentals = rentals.filter((r: Rental) => r.status === "active" || r.status === "confirmed");
  
  const todayRevenue = rentals
    .filter((r: Rental) => {
      const rentalDate = new Date(r.createdAt!);
      const today = new Date();
      return rentalDate.toDateString() === today.toDateString();
    })
    .reduce((sum: number, r: Rental) => sum + parseFloat(r.totalAmount), 0);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-blue-100 text-blue-800">Confirmed</Badge>;
      case "active":
        return <Badge className="bg-yellow-100 text-yellow-800">Active</Badge>;
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "cancelled":
        return <Badge className="bg-red-100 text-red-800">Cancelled</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getAvailabilityBadge = (isAvailable: boolean) => {
    return isAvailable ? (
      <Badge className="bg-green-100 text-green-800">Available</Badge>
    ) : (
      <Badge className="bg-red-100 text-red-800">Rented</Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-2">
            <Settings className="h-8 w-8 text-university-blue" />
            <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
          </div>
          <p className="text-gray-600">Manage inventory, rentals, and monitor platform performance</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Items</p>
                  <p className="text-2xl font-bold text-gray-900">{products.length}</p>
                </div>
                <div className="w-12 h-12 bg-university-blue/10 rounded-lg flex items-center justify-center">
                  <Box className="text-university-blue" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Available Now</p>
                  <p className="text-2xl font-bold text-success-green">{availableProducts.length}</p>
                </div>
                <div className="w-12 h-12 bg-success-green/10 rounded-lg flex items-center justify-center">
                  <CheckCircle className="text-success-green" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Currently Rented</p>
                  <p className="text-2xl font-bold text-amber-accent">{unavailableProducts.length}</p>
                </div>
                <div className="w-12 h-12 bg-amber-accent/10 rounded-lg flex items-center justify-center">
                  <Clock className="text-amber-accent" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Revenue Today</p>
                  <p className="text-2xl font-bold text-gray-900">₹{todayRevenue.toFixed(0)}</p>
                </div>
                <div className="w-12 h-12 bg-success-green/10 rounded-lg flex items-center justify-center">
                  <IndianRupee className="text-success-green" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Rentals */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>Active Rentals</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {rentalsLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : activeRentals.length === 0 ? (
              <p className="text-gray-600 text-center py-8">No active rentals at the moment</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rental ID</TableHead>
                      <TableHead>Product</TableHead>
                      <TableHead>User ID</TableHead>
                      <TableHead>Period</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activeRentals.map((rental: Rental) => {
                      const product = products.find((p: Product) => p.id === rental.productId);
                      return (
                        <TableRow key={rental.id}>
                          <TableCell className="font-medium">#{rental.id}</TableCell>
                          <TableCell>{product?.name || "Unknown Product"}</TableCell>
                          <TableCell className="text-gray-600">{rental.userId}</TableCell>
                          <TableCell>
                            {new Date(rental.startDate).toLocaleDateString()} - {new Date(rental.endDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell>₹{rental.totalAmount}</TableCell>
                          <TableCell>{getStatusBadge(rental.status)}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Product Inventory */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Box className="h-5 w-5" />
              <span>Product Inventory</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {productsLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Condition</TableHead>
                      <TableHead>Daily Rate</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Rating</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product: Product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-lg"></div>
                            <div>
                              <div className="font-medium text-gray-900">{product.name}</div>
                              <div className="text-sm text-gray-500">{product.subcategory}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{product.category}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{product.condition}</Badge>
                        </TableCell>
                        <TableCell>₹{product.dailyRate}</TableCell>
                        <TableCell>{getAvailabilityBadge(product.isAvailable)}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <span>{product.rating}</span>
                            <span className="text-gray-500">({product.reviewCount})</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
