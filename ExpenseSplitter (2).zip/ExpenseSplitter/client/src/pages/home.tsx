import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import Navigation from "@/components/navigation";
import ProductCard from "@/components/product-card";
import RentalModal from "@/components/rental-modal";
import { Search } from "lucide-react";
import type { Product } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [priceRange, setPriceRange] = useState<string>("all");
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [sortBy, setSortBy] = useState("relevance");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["/api/products", searchQuery, selectedCategory],
    queryFn: async () => {
      let url = "/api/products";
      const params = new URLSearchParams();
      
      if (searchQuery) params.append("search", searchQuery);
      if (selectedCategory !== "all") params.append("category", selectedCategory);
      
      if (params.toString()) url += "?" + params.toString();
      
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch products");
      return response.json();
    },
  });

  const filteredProducts = products.filter((product: Product) => {
    if (onlyAvailable && !product.isAvailable) return false;
    
    if (priceRange !== "all") {
      const dailyRate = parseFloat(product.dailyRate);
      switch (priceRange) {
        case "under-50":
          if (dailyRate >= 50) return false;
          break;
        case "50-200":
          if (dailyRate < 50 || dailyRate > 200) return false;
          break;
        case "over-200":
          if (dailyRate <= 200) return false;
          break;
      }
    }
    
    return true;
  });

  const sortedProducts = [...filteredProducts].sort((a: Product, b: Product) => {
    switch (sortBy) {
      case "price-low":
        return parseFloat(a.dailyRate) - parseFloat(b.dailyRate);
      case "price-high":
        return parseFloat(b.dailyRate) - parseFloat(a.dailyRate);
      case "rating":
        return parseFloat(b.rating || "0") - parseFloat(a.rating || "0");
      case "newest":
        return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
      default:
        return 0;
    }
  });

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "Books", label: "Textbooks" },
    { value: "Calculators", label: "Calculators" },
    { value: "Lab Equipment", label: "Lab Equipment" },
    { value: "Sports Uniforms", label: "Sports Gear" },
    { value: "Electronics", label: "Electronics" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <aside className="lg:w-1/4">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg mb-4 text-gray-900">Filters</h3>
                
                {/* Search */}
                <div className="mb-6">
                  <Label className="text-sm font-medium text-gray-700 mb-2">Search</Label>
                  <div className="relative">
                    <Input
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                  </div>
                </div>
                
                {/* Category Filter */}
                <div className="mb-6">
                  <Label className="text-sm font-medium text-gray-700 mb-3">Category</Label>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={category.value}
                          checked={selectedCategory === category.value}
                          onCheckedChange={() => setSelectedCategory(category.value)}
                        />
                        <Label htmlFor={category.value} className="text-sm text-gray-600">
                          {category.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div className="mb-6">
                  <Label className="text-sm font-medium text-gray-700 mb-3">Daily Rental Price</Label>
                  <RadioGroup value={priceRange} onValueChange={setPriceRange}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="all" id="all-prices" />
                      <Label htmlFor="all-prices" className="text-sm text-gray-600">All Prices</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="under-50" id="under-50" />
                      <Label htmlFor="under-50" className="text-sm text-gray-600">Under ₹50</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="50-200" id="50-200" />
                      <Label htmlFor="50-200" className="text-sm text-gray-600">₹50 - ₹200</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="over-200" id="over-200" />
                      <Label htmlFor="over-200" className="text-sm text-gray-600">₹200+</Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Availability */}
                <div className="mb-6">
                  <Label className="text-sm font-medium text-gray-700 mb-3">Availability</Label>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="available-only"
                      checked={onlyAvailable}
                      onCheckedChange={setOnlyAvailable}
                    />
                    <Label htmlFor="available-only" className="text-sm text-gray-600">
                      Available Now Only
                    </Label>
                  </div>
                </div>

                {/* Clear Filters */}
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("all");
                    setPriceRange("all");
                    setOnlyAvailable(false);
                    setSortBy("relevance");
                  }}
                >
                  Clear All Filters
                </Button>
              </CardContent>
            </Card>
          </aside>

          {/* Product Grid */}
          <div className="lg:w-3/4">
            {/* Results Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Available Rentals</h2>
                <p className="text-gray-600">
                  Showing {sortedProducts.length} of {products.length} items
                </p>
              </div>
              
              {/* Sort Dropdown */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Sort by: Relevance</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Most Popular</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Product Cards Grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, index) => (
                  <Card key={index}>
                    <Skeleton className="h-48 w-full" />
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-3 w-full mb-2" />
                      <Skeleton className="h-3 w-2/3 mb-4" />
                      <Skeleton className="h-10 w-full" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {sortedProducts.map((product: Product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onRentNow={() => setSelectedProduct(product)}
                  />
                ))}
              </div>
            )}

            {/* Empty State */}
            {!isLoading && sortedProducts.length === 0 && (
              <Card>
                <CardContent className="p-12 text-center">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No products found</h3>
                  <p className="text-gray-600 mb-4">
                    Try adjusting your filters or search terms
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedCategory("all");
                      setPriceRange("all");
                      setOnlyAvailable(false);
                    }}
                  >
                    Clear Filters
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* Rental Modal */}
      {selectedProduct && (
        <RentalModal
          product={selectedProduct}
          isOpen={!!selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}
