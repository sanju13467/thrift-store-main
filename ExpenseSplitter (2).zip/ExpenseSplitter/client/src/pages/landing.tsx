import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GraduationCap, Book, Calculator, ShirtIcon, Dumbbell, Volume2 } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-university-blue rounded-lg flex items-center justify-center">
                <GraduationCap className="text-white" size={20} />
              </div>
              <div>
                <h1 className="font-bold text-lg text-gray-900">Campus Rental</h1>
                <p className="text-xs text-gray-500">University Marketplace</p>
              </div>
            </div>
            
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-university-blue hover:bg-university-blue/90"
            >
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-university-blue to-university-light text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-5xl font-bold mb-4">Rent. Study. Succeed.</h2>
          <p className="text-xl mb-8 opacity-90">
            Everything you need for academic success, available for rent at student-friendly prices
          </p>
          
          {/* Quick Category Cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/20 transition-colors">
              <Book className="mx-auto mb-2" size={32} />
              <p className="text-sm font-medium">Textbooks</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/20 transition-colors">
              <Calculator className="mx-auto mb-2" size={32} />
              <p className="text-sm font-medium">Calculators</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/20 transition-colors">
              <ShirtIcon className="mx-auto mb-2" size={32} />
              <p className="text-sm font-medium">Lab Gear</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/20 transition-colors">
              <Dumbbell className="mx-auto mb-2" size={32} />
              <p className="text-sm font-medium">Sports</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/20 transition-colors">
              <Volume2 className="mx-auto mb-2" size={32} />
              <p className="text-sm font-medium">Electronics</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Campus Rental?</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We make academic resources accessible and affordable for every student
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-university-blue/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Book className="text-university-blue" size={24} />
                </div>
                <h4 className="font-semibold text-lg mb-2">Quality Equipment</h4>
                <p className="text-gray-600">All items are sanitized and quality-checked before every rental</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-success-green/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Calculator className="text-success-green" size={24} />
                </div>
                <h4 className="font-semibold text-lg mb-2">Student-Friendly Pricing</h4>
                <p className="text-gray-600">Affordable daily and weekly rates designed for student budgets</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-amber-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <GraduationCap className="text-amber-accent" size={24} />
                </div>
                <h4 className="font-semibold text-lg mb-2">University Verified</h4>
                <p className="text-gray-600">Trusted by students and faculty across campus</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-university-blue text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-4">Ready to Get Started?</h3>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of students who save money with Campus Rental
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-white text-university-blue hover:bg-gray-100"
          >
            Sign In to Browse Rentals
          </Button>
        </div>
      </section>
    </div>
  );
}
