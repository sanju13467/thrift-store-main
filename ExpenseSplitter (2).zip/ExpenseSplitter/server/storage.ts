import {
  users,
  products,
  rentals,
  wishlist,
  type User,
  type UpsertUser,
  type Product,
  type InsertProduct,
  type Rental,
  type InsertRental,
  type WishlistItem,
  type InsertWishlistItem,
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  getProductsByCategory(category: string): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  
  // Rental operations
  createRental(rental: InsertRental): Promise<Rental>;
  getRentalsByUser(userId: string): Promise<Rental[]>;
  getAllRentals(): Promise<Rental[]>;
  updateRentalStatus(id: number, status: string): Promise<Rental | undefined>;
  
  // Wishlist operations
  addToWishlist(item: InsertWishlistItem): Promise<WishlistItem>;
  removeFromWishlist(userId: string, productId: number): Promise<boolean>;
  getUserWishlist(userId: string): Promise<WishlistItem[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<number, Product>;
  private rentals: Map<number, Rental>;
  private wishlistItems: Map<number, WishlistItem>;
  private currentProductId: number;
  private currentRentalId: number;
  private currentWishlistId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.rentals = new Map();
    this.wishlistItems = new Map();
    this.currentProductId = 1;
    this.currentRentalId = 1;
    this.currentWishlistId = 1;
    
    // Initialize with sample products
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Advanced Calculus - 8th Edition",
        description: "Complete with solutions manual. Perfect for Engineering Mathematics courses.",
        category: "Books",
        subcategory: "2023",
        imageUrl: "https://images.unsplash.com/photo-1509228468518-180dd4864904?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        dailyRate: "85.00",
        weeklyRate: "450.00",
        securityDeposit: "500.00",
        isAvailable: true,
        condition: "Good",
        rating: "4.8",
        reviewCount: 24,
      },
      {
        name: "TI-84 Plus CE Calculator",
        description: "Graphing calculator with color display. Includes charging cable and manual.",
        category: "Calculators",
        subcategory: "Texas Instruments",
        imageUrl: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        dailyRate: "120.00",
        weeklyRate: "650.00",
        securityDeposit: "800.00",
        isAvailable: true,
        condition: "Excellent",
        rating: "4.9",
        reviewCount: 31,
      },
      {
        name: "Chemistry Lab Apron",
        description: "Chemical-resistant apron with adjustable straps. Freshly sanitized after each use.",
        category: "Lab Equipment",
        subcategory: "Size M",
        imageUrl: "https://images.unsplash.com/photo-1582719471384-894fbb16e074?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        dailyRate: "45.00",
        weeklyRate: "250.00",
        securityDeposit: "200.00",
        isAvailable: true,
        condition: "Good",
        rating: "4.6",
        reviewCount: 18,
      },
      {
        name: "Basketball Uniform Set",
        description: "Complete uniform set with jersey and shorts. Includes team number customization.",
        category: "Sports Uniforms",
        subcategory: "Size L",
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        dailyRate: "95.00",
        weeklyRate: "500.00",
        securityDeposit: "300.00",
        isAvailable: true,
        condition: "Good",
        rating: "4.7",
        reviewCount: 12,
      },
      {
        name: "JBL Charge 5 Speaker",
        description: "Waterproof portable speaker with 20-hour battery life. Perfect for events.",
        category: "Electronics",
        subcategory: "JBL",
        imageUrl: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        dailyRate: "180.00",
        weeklyRate: "950.00",
        securityDeposit: "1200.00",
        isAvailable: false,
        condition: "Excellent",
        rating: "4.9",
        reviewCount: 45,
      },
      {
        name: "Quantum Physics Textbook",
        description: "Comprehensive guide to quantum mechanics with practice problems and solutions.",
        category: "Books",
        subcategory: "2023",
        imageUrl: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        dailyRate: "110.00",
        weeklyRate: "600.00",
        securityDeposit: "600.00",
        isAvailable: true,
        condition: "Good",
        rating: "4.8",
        reviewCount: 29,
      },
    ];

    sampleProducts.forEach((product) => {
      const id = this.currentProductId++;
      const productWithId: Product = {
        ...product,
        id,
        subcategory: product.subcategory || null,
        imageUrl: product.imageUrl || null,
        isAvailable: product.isAvailable ?? true,
        condition: product.condition || "Good",
        rating: product.rating || null,
        reviewCount: product.reviewCount || null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.products.set(id, productWithId);
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id);
    const user: User = {
      ...userData,
      email: userData.email || null,
      firstName: userData.firstName || null,
      lastName: userData.lastName || null,
      profileImageUrl: userData.profileImageUrl || null,
      isAdmin: userData.isAdmin || null,
      createdAt: existingUser?.createdAt || new Date(),
      updatedAt: new Date(),
    };
    this.users.set(userData.id, user);
    return user;
  }

  // Product operations
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(productData: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = {
      ...productData,
      id,
      subcategory: productData.subcategory || null,
      imageUrl: productData.imageUrl || null,
      isAvailable: productData.isAvailable ?? true,
      condition: productData.condition || "Good",
      rating: productData.rating || null,
      reviewCount: productData.reviewCount || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) return undefined;
    
    const updated: Product = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.category === category
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm)
    );
  }

  // Rental operations
  async createRental(rentalData: InsertRental): Promise<Rental> {
    const id = this.currentRentalId++;
    const rental: Rental = {
      ...rentalData,
      id,
      status: rentalData.status || "confirmed",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.rentals.set(id, rental);
    
    // Update product availability
    await this.updateProduct(rentalData.productId, { isAvailable: false });
    
    return rental;
  }

  async getRentalsByUser(userId: string): Promise<Rental[]> {
    return Array.from(this.rentals.values()).filter(
      (rental) => rental.userId === userId
    );
  }

  async getAllRentals(): Promise<Rental[]> {
    return Array.from(this.rentals.values());
  }

  async updateRentalStatus(id: number, status: string): Promise<Rental | undefined> {
    const existing = this.rentals.get(id);
    if (!existing) return undefined;
    
    const updated: Rental = {
      ...existing,
      status,
      updatedAt: new Date(),
    };
    this.rentals.set(id, updated);
    
    // If rental is completed, make product available again
    if (status === "completed") {
      await this.updateProduct(existing.productId, { isAvailable: true });
    }
    
    return updated;
  }

  // Wishlist operations
  async addToWishlist(itemData: InsertWishlistItem): Promise<WishlistItem> {
    const id = this.currentWishlistId++;
    const item: WishlistItem = {
      ...itemData,
      id,
      createdAt: new Date(),
    };
    this.wishlistItems.set(id, item);
    return item;
  }

  async removeFromWishlist(userId: string, productId: number): Promise<boolean> {
    const item = Array.from(this.wishlistItems.values()).find(
      (item) => item.userId === userId && item.productId === productId
    );
    if (item) {
      return this.wishlistItems.delete(item.id);
    }
    return false;
  }

  async getUserWishlist(userId: string): Promise<WishlistItem[]> {
    return Array.from(this.wishlistItems.values()).filter(
      (item) => item.userId === userId
    );
  }
}

export const storage = new MemStorage();
